#!/usr/bin/env bash
set -euo pipefail

target=${1:?target session ordinal}
user_target=${2:?target user ordinal}
apple_target=${3:?even target user ordinal}

run() {
  local label=$1 sql=$2
  local out
  out=$(
    {
      printf '%s\n' 'SET max_parallel_workers_per_gather=0; SET jit=off;'
      for _ in 1 2 3 4 5 6; do
        printf 'EXPLAIN (ANALYZE, BUFFERS%s) %s;\n' "${4:-}" "$sql"
      done
    } | docker exec -i erg-dba-access-pg psql -U postgres -X -q
  )
  printf '%s\n' "$out" | awk -v label="$label" '
    /Execution Time:/ {n++; if (n > 1) a[n-1]=$3}
    END {
      for(i=1;i<=5;i++) for(j=i+1;j<=5;j++) if(a[i]>a[j]) {t=a[i];a[i]=a[j];a[j]=t}
      printf "%s median_ms=%.3f runs_ms=%.3f,%.3f,%.3f,%.3f,%.3f\n", label,a[3],a[1],a[2],a[3],a[4],a[5]
    }'
}

run resolve_session "SELECT sessions.id,sessions.token_hash,sessions.user_id,sessions.created_at,sessions.expires_at,users.id,users.google_sub,users.apple_sub,users.email,users.name,users.created_at FROM sessions INNER JOIN users ON sessions.user_id=users.id WHERE sessions.token_hash=md5('token-a-${target}') || md5('token-b-${target}')"
run original_baseline "SELECT id,user_id AS \"userId\" FROM sessions WHERE id=md5('session-${target}')::uuid AND expires_at>now()"
run original_policy "SELECT sessions.id,sessions.user_id AS \"userId\",users.email FROM sessions INNER JOIN users ON sessions.user_id=users.id WHERE sessions.id=md5('session-${target}')::uuid AND sessions.expires_at>now()"
run original_baseline_lock "SELECT id,user_id AS \"userId\" FROM sessions WHERE id=md5('session-${target}')::uuid AND expires_at>now() FOR UPDATE"
run original_policy_lock "SELECT sessions.id,sessions.user_id AS \"userId\",users.email FROM sessions INNER JOIN users ON sessions.user_id=users.id WHERE sessions.id=md5('session-${target}')::uuid AND sessions.expires_at>now() FOR UPDATE"
run subject_google "SELECT id,email,name FROM users WHERE google_sub='google-${user_target}'"
run subject_apple "SELECT id,email,name FROM users WHERE apple_sub='apple-${apple_target}'"
run legacy_upsert "INSERT INTO users(google_sub,email,name) VALUES('google-${user_target}','provider-current@synthetic.test','Provider Name') ON CONFLICT(google_sub) DO UPDATE SET name=excluded.name RETURNING id,email,name" ', WAL'
run profile_update_baseline "UPDATE users SET email='provider-current@synthetic.test',name='Provider Name' WHERE id=md5('user-${user_target}')::uuid" ', WAL'
run profile_update_policy "UPDATE users SET name='Provider Name' WHERE id=md5('user-${user_target}')::uuid" ', WAL'
