#!/usr/bin/env bash
set -euo pipefail

uid="md5('user-100000')::uuid"
sid="md5('session-1000000')::uuid"

docker exec -i erg-dba-access-pg psql -U postgres -X -q <<SQL &
BEGIN;
SELECT id FROM users WHERE id=$uid FOR UPDATE;
SELECT pg_sleep(3);
ROLLBACK;
SQL
user_holder=$!
sleep 0.3

docker exec -i erg-dba-access-pg psql -U postgres -X -q <<SQL &
BEGIN;
SELECT sessions.id,sessions.user_id,users.email
FROM sessions INNER JOIN users ON sessions.user_id=users.id
WHERE sessions.id=$sid AND sessions.expires_at>now()
FOR UPDATE;
ROLLBACK;
SQL
join_waiter=$!
sleep 0.5

set +e
out=$(docker exec -i erg-dba-access-pg psql -U postgres -X -v ON_ERROR_STOP=1 -Atqc "SET lock_timeout='250ms'; UPDATE sessions SET expires_at=expires_at WHERE id=$sid" 2>&1)
rc=$?
set -e
printf 'join_waiting_on_user_then_same_session_update rc=%s output=%s\n' "$rc" "${out//$'\n'/ }"

wait "$user_holder"
wait "$join_waiter"

