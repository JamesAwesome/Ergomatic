# Historical migration fixture repair

Status: DONE

## Change

`app/server/db/schema.integration.test.ts` now seeds every migration-suite user
through one raw helper pinned to the columns present since migration 0000:
`google_sub`, `email`, and `name`, returning only `id`. The test no longer
imports the current Drizzle `users` model, so future additive user columns do
not leak into deliberately old schemas. The migration 0021 teardown now guards
its second temporary directory when setup fails before that directory exists.

No product source or migration changed. All original migration behavior
assertions remain unchanged; no new behavioral assertion was added. Those
assertions are the oracle because this correction changes only how their
historical prerequisites are inserted.

## Red evidence and root cause

- Parent aggregate evidence: `coverage-initial-failed.log` exited 1 with 342 passing files,
  this file failed, 5 tests failed, 8 suite/teardown failures were reported,
  and 24 historical assertions were skipped.
- Scoped pre-fix reproduction: `legacy-fixture-red.log` reported 1 failed test
  file, 5 failed tests, 4 passed, and 24 skipped. Each first failure emitted
  `insert into users (... apple_sub ...)` against a pre-0031 schema and
  Postgres `42703: column apple_sub does not exist`.
- The extra original teardown failure was `rm(undefined)` in migration 0021
  after its setup stopped before assigning `tempDirThrough21`.

## Green evidence

- `pnpm test --project integration server/db/schema.integration.test.ts`:
  PASS, 1 file and 33/33 tests (`legacy-fixture-green.log`).
- Fresh post-mutation restore of the same command: PASS, 1 file and 33/33 tests
  (`legacy-fixture-restored-green.log`).
- `pnpm lint`: PASS, including suppression, NUL, transport, and mock censuses.
- `pnpm typecheck`: PASS; E2E TypeScript membership 25/25.
- `pnpm format:check`: PASS.
- `git diff --check -- server/db/schema.integration.test.ts`: PASS.
- Comment sweep for current-schema/typed-user fixture claims: only the new
  helper rationale remains; no stale `.insert(users)` seed remains.

The parent owns the aggregate coverage rerun, so no broad coverage command was
run here. Per-file coverage is N/A: the only touched file is a test file, which
is not an instrumented production source.

## Deciding-source mutation

After commit, the helper was mutated back to the current Drizzle
`.insert(users).values(user).returning()` path. The scoped integration command
exited 1 with 1 failed file, 5 failed tests, 4 passed, and 24 skipped; its first
failures were again Postgres `42703` on `apple_sub`
(`legacy-fixture-mutation-red.log`). The run produced 12 failure records rather
than the original 13 and no undefined-path teardown error, independently
exercising the cleanup guard. Restoring the raw helper left the owned file
byte-identical to the commit and returned the suite to 33/33 passing.

## Commit and ownership

Commit: `1ecd4a19` (`Repair historical migration user fixtures`).

Immediately before commit, `git rev-parse --show-toplevel` printed
`/Users/james/projects/github/jamesawesome/Ergomatic/.claude/worktrees/wave-a-apple`,
and `git diff --cached --name-only` listed only
`app/server/db/schema.integration.test.ts`. The real pre-commit hook ran
Prettier, ESLint, and the whole typecheck successfully. The commit contains
only the owned test file. Other agents' unstaged work was left untouched.

Brief contradictions: none.
