#!/usr/bin/env bash
set -euo pipefail

user_id="md5('user-100000')::uuid"
session_id="md5('session-1000000')::uuid"

hold() {
  local query=$1
  docker exec -i erg-dba-access-pg psql -U postgres -X -q <<SQL &
BEGIN;
$query;
SELECT pg_sleep(2);
ROLLBACK;
SQL
  holder=$!
  sleep 0.3
}

probe() {
  local label=$1 query=$2
  local started ended rc out
  started=$(python3 -c 'import time; print(time.monotonic_ns())')
  set +e
  out=$(docker exec -i erg-dba-access-pg psql -U postgres -X -v ON_ERROR_STOP=1 -Atqc "SET lock_timeout='250ms'; $query" 2>&1)
  rc=$?
  set -e
  ended=$(python3 -c 'import time; print(time.monotonic_ns())')
  printf '%s rc=%s elapsed_ms=%s output=%s\n' "$label" "$rc" "$(( (ended-started)/1000000 ))" "${out//$'\n'/ }"
}

hold "SELECT id,user_id FROM sessions WHERE id=$session_id AND expires_at>now() FOR UPDATE"
probe baseline_lock_same_user_update "UPDATE users SET name=name WHERE id=$user_id"
probe baseline_lock_same_session_update "UPDATE sessions SET expires_at=expires_at WHERE id=$session_id"
wait "$holder"

hold "SELECT sessions.id,sessions.user_id,users.email FROM sessions INNER JOIN users ON sessions.user_id=users.id WHERE sessions.id=$session_id AND sessions.expires_at>now() FOR UPDATE"
probe policy_lock_same_user_update "UPDATE users SET name=name WHERE id=$user_id"
probe policy_lock_other_user_update "UPDATE users SET name=name WHERE id=md5('user-99999')::uuid"
probe policy_lock_same_session_update "UPDATE sessions SET expires_at=expires_at WHERE id=$session_id"
wait "$holder"

