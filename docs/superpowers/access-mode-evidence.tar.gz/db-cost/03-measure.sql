\set ON_ERROR_STOP on
SET max_parallel_workers_per_gather = 0;
SET jit = off;

\echo ENVIRONMENT
SELECT version();
SELECT name, setting, unit FROM pg_settings
WHERE name IN ('work_mem','shared_buffers','jit','max_parallel_workers_per_gather')
ORDER BY name;
SELECT count(*) AS users, (SELECT count(*) FROM sessions) AS sessions FROM users;

\echo EXPLAIN_RESOLVE_SESSION
EXPLAIN (ANALYZE, BUFFERS)
SELECT sessions.id, sessions.token_hash, sessions.user_id, sessions.created_at,
       sessions.expires_at, users.id, users.google_sub, users.apple_sub,
       users.email, users.name, users.created_at
FROM sessions INNER JOIN users ON sessions.user_id=users.id
WHERE sessions.token_hash=md5('token-a-' || :'target') || md5('token-b-' || :'target');

\echo EXPLAIN_ORIGINAL_BASELINE
EXPLAIN (ANALYZE, BUFFERS)
SELECT id,user_id AS "userId" FROM sessions
WHERE id=md5('session-' || :'target')::uuid AND expires_at>now();

\echo EXPLAIN_ORIGINAL_POLICY
EXPLAIN (ANALYZE, BUFFERS)
SELECT sessions.id,sessions.user_id AS "userId",users.email
FROM sessions INNER JOIN users ON sessions.user_id=users.id
WHERE sessions.id=md5('session-' || :'target')::uuid AND sessions.expires_at>now();

\echo EXPLAIN_SUBJECT_LOOKUP_GOOGLE
EXPLAIN (ANALYZE, BUFFERS)
SELECT id,email,name FROM users WHERE google_sub='google-' || :'user_target';

\echo EXPLAIN_SUBJECT_LOOKUP_APPLE
EXPLAIN (ANALYZE, BUFFERS)
SELECT id,email,name FROM users WHERE apple_sub='apple-' || :'apple_target';

\echo EXPLAIN_LEGACY_UPSERT_EXISTING
EXPLAIN (ANALYZE, BUFFERS, WAL)
INSERT INTO users(google_sub,email,name)
VALUES('google-' || :'user_target','provider-current@synthetic.test','Provider Name')
ON CONFLICT(google_sub) DO UPDATE SET name=excluded.name
RETURNING id,email,name;

\echo BOUNDS_AND_PAYLOAD_CONTENT_BYTES
SELECT
  (SELECT count(*) FROM sessions WHERE token_hash=md5('token-a-' || :'target') || md5('token-b-' || :'target')) AS resolve_rows,
  (SELECT count(*) FROM sessions WHERE id=md5('session-' || :'target')::uuid AND expires_at>now()) AS original_rows,
  (SELECT octet_length(s.id::text)+octet_length(s.user_id::text) FROM sessions s WHERE s.id=md5('session-' || :'target')::uuid) AS original_baseline_content_bytes,
  (SELECT octet_length(s.id::text)+octet_length(s.user_id::text)+octet_length(u.email) FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=md5('session-' || :'target')::uuid) AS original_policy_content_bytes,
  (SELECT octet_length(u.id::text)+octet_length(u.email)+octet_length(u.name) FROM users u WHERE u.google_sub='google-' || :'user_target') AS subject_lookup_content_bytes;

