\set ON_ERROR_STOP on
SET synchronous_commit = off;

TRUNCATE auth_attempts, apple_grants, sessions, users CASCADE;

INSERT INTO users(id, google_sub, apple_sub, email, name, created_at)
SELECT md5('user-' || g)::uuid,
       'google-' || g,
       CASE WHEN g % 2 = 0 THEN 'apple-' || g ELSE NULL END,
       'rower-' || g || '@synthetic.test',
       'Synthetic ' || g,
       now() - (g % 365) * interval '1 day'
FROM generate_series(1, 5) AS g;

INSERT INTO sessions(id, token_hash, user_id, created_at, expires_at)
SELECT md5('session-' || g)::uuid,
       md5('token-a-' || g) || md5('token-b-' || g),
       md5('user-' || (((g - 1) % 5) + 1))::uuid,
       now() - interval '1 day',
       now() + interval '60 days'
FROM generate_series(1, 25) AS g;

VACUUM (ANALYZE) users;
VACUUM (ANALYZE) sessions;

